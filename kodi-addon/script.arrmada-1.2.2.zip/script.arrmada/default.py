# -*- coding: utf-8 -*-
"""ArrMada Video Plugin & Overseerr Discovery for Kodi."""

from __future__ import annotations

import sys
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Add lib directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "lib"))

from api import ArrMadaAPI
from kodi_helper import show_notification, confirm_dialog
import search_media

ADDON = xbmcaddon.Addon("script.arrmada")
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
PLUGIN_URL = sys.argv[0] if len(sys.argv) > 0 else "plugin://script.arrmada/"


def add_dir(name: str, action: str, icon: str = "", fanart: str = "", params: dict = None, is_folder: bool = True):
    """Add a directory folder item."""
    query = {"action": action}
    if params:
        query.update(params)
    url = f"{PLUGIN_URL}?{urllib.parse.urlencode(query)}"
    li = xbmcgui.ListItem(label=name)
    art = {}
    if icon:
        art["icon"] = icon
        art["thumb"] = icon
    if fanart:
        art["fanart"] = fanart
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)


def add_media_item(item: dict):
    """Add a rich media card item with poster, synopsis, fanart, rating."""
    title = item.get("title") or "Sans titre"
    year = item.get("year")
    mtype = item.get("type", "movie")
    in_lib = item.get("in_library", False)
    plot = item.get("overview") or "Aucun synopsis disponible."
    poster = item.get("poster_url") or ""
    backdrop = item.get("backdrop_url") or poster
    rating = item.get("rating") or 0.0

    # Badge in title
    badge = " [✅ En médiathèque]" if in_lib else " [➕ Demander]"
    year_str = f" ({year})" if year else ""
    display_title = f"{title}{year_str}{badge}"

    li = xbmcgui.ListItem(label=display_title)

    # Set Posters, Fanart & Thumbnails
    art_dict = {}
    if poster:
        art_dict["poster"] = poster
        art_dict["thumb"] = poster
        art_dict["icon"] = poster
    if backdrop:
        art_dict["fanart"] = backdrop
    if art_dict:
        li.setArt(art_dict)

    # Set Video Info (synopsis, year, rating, mediatype)
    video_info = {
        "title": title,
        "plot": plot,
        "mediatype": "movie" if mtype == "movie" else "tvshow",
    }
    if year:
        try:
            video_info["year"] = int(year)
        except Exception:
            pass
    if rating:
        try:
            video_info["rating"] = float(rating)
        except Exception:
            pass

    try:
        li.setInfo("video", video_info)
    except Exception:
        pass

    params = {
        "action": "media_details",
        "title": title,
        "type": mtype,
        "tmdb_id": str(item.get("tmdb_id") or ""),
        "tvdb_id": str(item.get("tvdb_id") or ""),
        "in_library": "1" if in_lib else "0",
        "arr_id": str(item.get("arr_id") or ""),
        "overview": plot,
        "poster_url": poster,
        "year": str(year or ""),
    }
    url = f"{PLUGIN_URL}?{urllib.parse.urlencode(params)}"
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)


def show_root_menu():
    """Build the main category menu."""
    xbmcplugin.setPluginCategory(HANDLE, "ArrMada")
    xbmcplugin.setContent(HANDLE, "files")

    add_dir("🔍 Rechercher un film ou une série...", "search_input", is_folder=False)
    add_dir("🌟 Films Tendances & Populaires (TMDB)", "trending_movies")
    add_dir("📺 Séries Tendances & Populaires (TMDB)", "trending_series")
    add_dir("💡 Recommandations selon votre médiathèque", "recommendations")
    add_dir("📊 Console & Santé de la Stack (HUD)", "dashboard_popup", is_folder=False)
    add_dir("📥 Téléchargements actifs (SABnzbd / Torrent)", "downloads", is_folder=False)
    add_dir("🔄 Lancer le scan de la médiathèque Kodi", "sync", is_folder=False)
    add_dir("🧹 Nettoyer la médiathèque Kodi (Clean)", "clean", is_folder=False)
    add_dir("⚙️ Paramètres ArrMada", "settings", is_folder=False)

    xbmcplugin.endOfDirectory(HANDLE)




def show_trending_movies():
    """Show trending movies with covers and plots."""
    xbmcplugin.setPluginCategory(HANDLE, "Films Tendances")
    xbmcplugin.setContent(HANDLE, "movies")

    data = ArrMadaAPI.get_recommendations()
    movies = data.get("trending_movies", [])

    if not movies:
        show_notification("ArrMada", "Aucun film tendance récupéré", is_error=True)
    else:
        for m in movies:
            add_media_item(m)

    xbmcplugin.endOfDirectory(HANDLE)


def show_trending_series():
    """Show trending series with covers and plots."""
    xbmcplugin.setPluginCategory(HANDLE, "Séries Tendances")
    xbmcplugin.setContent(HANDLE, "tvshows")

    data = ArrMadaAPI.get_recommendations()
    series = data.get("trending_series", [])

    if not series:
        show_notification("ArrMada", "Aucune série tendance récupérée", is_error=True)
    else:
        for s in series:
            add_media_item(s)

    xbmcplugin.endOfDirectory(HANDLE)


def show_recommendations():
    """Show library-based recommendations with covers."""
    xbmcplugin.setPluginCategory(HANDLE, "Recommandations")
    xbmcplugin.setContent(HANDLE, "movies")

    data = ArrMadaAPI.get_recommendations()
    because = data.get("because_you_have", [])

    items_added = 0
    for block in because:
        rec_items = block.get("recommendations", [])
        for it in rec_items:
            add_media_item(it)
            items_added += 1

    if items_added == 0:
        # Fallback to wanted list
        wanted = data.get("wanted", [])
        for w in wanted:
            add_media_item(w)

    xbmcplugin.endOfDirectory(HANDLE)


def handle_search_results(query: str):
    """Display media search results with rich posters and metadata."""
    xbmcplugin.setPluginCategory(HANDLE, f"Résultats pour : {query}")
    xbmcplugin.setContent(HANDLE, "movies")

    results = ArrMadaAPI.lookup_media(query)
    if not results:
        show_notification("ArrMada", f"Aucun résultat pour '{query}'", is_error=False)
    else:
        for it in results:
            add_media_item(it)

    xbmcplugin.endOfDirectory(HANDLE)


def show_media_details_dialog(params: dict):
    """Handle click on a poster: show detail popup and launch 3-step wizard or release picker."""
    title = params.get("title", "")
    mtype = params.get("type", "movie")
    in_lib = params.get("in_library") == "1"
    arr_id_str = params.get("arr_id", "")
    arr_id = int(arr_id_str) if arr_id_str.isdigit() else None
    plot = params.get("overview", "Aucun synopsis.")
    year = params.get("year", "")
    tmdb_id = params.get("tmdb_id") or None
    tvdb_id = params.get("tvdb_id") or None

    header = f"{title}"
    if year:
        header += f" ({year})"

    status_tag = "✅ Déjà dans votre médiathèque" if in_lib else "➕ Non possédé"

    options = []
    if in_lib and arr_id:
        options.append(("🎯 Choisir une Release manuellement (Torrent vs Usenet)", "pick_release"))
        options.append(("🚀 Forcer la recherche automatique d'une meilleure release", "auto_search"))
        options.append(("📖 Lire le synopsis complet", "show_plot"))
    else:
        options.append(("🎛️ Demander & Télécharger (Qualité 1080p/4K, Dossier, Releases)", "add_wizard"))
        options.append(("📖 Lire le synopsis complet", "show_plot"))

    choice = xbmcgui.Dialog().select(f"🏴‍☠️ {header} — {status_tag}", [o[0] for o in options])
    if choice < 0:
        return

    action = options[choice][1]

    if action == "show_plot":
        xbmcgui.Dialog().textviewer(f"Synopsis : {title}", plot)

    elif action == "pick_release" and arr_id:
        search_media.pick_and_grab_release(mtype, arr_id, title)

    elif action == "auto_search":
        show_notification("ArrMada", f"Recherche en cours pour {title}...", time_ms=2500)
        res = ArrMadaAPI.trigger_search({"title": title, "media_type": mtype})
        if res.get("status") == "ok":
            show_notification("ArrMada", res.get("message") or "Recherche lancée !", is_error=False, time_ms=4500)
        else:
            show_notification("ArrMada", res.get("message") or "Erreur", is_error=True, time_ms=5000)

    elif action == "add_wizard":
        # 3-step wizard
        opts = ArrMadaAPI.get_media_options(mtype)
        profiles = opts.get("profiles", [])
        folders = opts.get("root_folders", [])

        if not profiles:
            show_notification("ArrMada", "Aucun profil de qualité configuré", is_error=True)
            return
        if not folders:
            show_notification("ArrMada", "Aucun dossier de destination configuré", is_error=True)
            return

        # Step 1: Quality
        prof_choice = xbmcgui.Dialog().select(f"Étape 1/3 — Choisir la Qualité pour {title}", [p['name'] for p in profiles])
        if prof_choice < 0:
            return
        chosen_profile = profiles[prof_choice]

        # Step 2: Folder
        folder_choice = xbmcgui.Dialog().select(f"Étape 2/3 — Dossier de destination", [f"{f['path']} ({search_media._format_size(f.get('free_space'))} libres)" for f in folders])
        if folder_choice < 0:
            return
        chosen_folder = folders[folder_choice]['path']

        # Step 3: Mode
        mode_choice = xbmcgui.Dialog().select(f"Étape 3/3 — Mode de téléchargement", [
            "🚀 Téléchargement Automatique (Meilleure release)",
            "🎯 Choisir la Release manuellement (Torrent vs Usenet)",
        ])
        if mode_choice < 0:
            return

        if mode_choice == 0:
            show_notification("ArrMada", f"Ajout et recherche de {title}...", time_ms=3000)
            add_res = ArrMadaAPI.add_media({
                "type": mtype,
                "title": title,
                "tmdb_id": tmdb_id,
                "tvdb_id": tvdb_id,
                "quality_profile_id": chosen_profile.get("id"),
                "root_folder_path": chosen_folder,
                "search_now": True,
            })
            if add_res.get("status") == "ok":
                show_notification("ArrMada", f"'{title}' ajouté ! Téléchargement en cours...", is_error=False, time_ms=5000)
            else:
                show_notification("ArrMada", add_res.get("message") or "Erreur", is_error=True, time_ms=5000)
        else:
            show_notification("ArrMada", f"Ajout de {title}...", time_ms=2500)
            add_res = ArrMadaAPI.add_media({
                "type": mtype,
                "title": title,
                "tmdb_id": tmdb_id,
                "tvdb_id": tvdb_id,
                "quality_profile_id": chosen_profile.get("id"),
                "root_folder_path": chosen_folder,
                "search_now": False,
            })
            if add_res.get("status") != "ok":
                show_notification("ArrMada", add_res.get("message") or "Erreur", is_error=True, time_ms=5000)
                return
            new_id = add_res.get("arr_id")
            if new_id:
                search_media.pick_and_grab_release(mtype, new_id, title)


def show_downloads_dialog():
    """Show active downloads list."""
    res = ArrMadaAPI.get_addon_status()
    if res.get("status") != "ok":
        msg = res.get("message") or "Impossible de contacter ArrMada"
        show_notification("ArrMada", msg, is_error=True)
        return

    downloads = res.get("downloads", [])
    if not downloads:
        xbmcgui.Dialog().ok("ArrMada : Téléchargements", "Aucun téléchargement en cours dans SABnzbd / Torrent.")
        return

    items = []
    for d in downloads:
        title = d.get("title", "")
        progress = d.get("progress", 0)
        timeleft = d.get("timeleft") or ""
        service = d.get("service") or ""
        items.append(f"[{progress}%] {title} ({timeleft} - {service})")

    xbmcgui.Dialog().select("ArrMada : Téléchargements actifs", items)


def show_dashboard_dialog():
    """Display interactive Stack Health, Storage, and Activity Dashboard."""
    import dashboard
    dashboard.show_dashboard()



def show_dashboard_directory():
    """Display visual dashboard directory with stats, disks, services, and activities in Kodi."""
    xbmcplugin.setPluginCategory(HANDLE, "Tableau de bord")
    xbmcplugin.setContent(HANDLE, "files")

    data = ArrMadaAPI.get_dashboard()
    if not data or data.get("status") != "ok":
        show_notification("ArrMada", "Impossible de récupérer les statistiques", is_error=True)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    services = data.get("services", [])
    stats = data.get("stats", {})
    disks = data.get("disks", [])
    downloads = data.get("downloads", [])
    activities = data.get("recent_activities", [])

    online_svc = sum(1 for s in services if s.get("status") == "online")
    total_svc = len(services)
    m_count = stats.get("movies_count", 0)
    s_count = stats.get("series_count", 0)
    ep_count = stats.get("episodes_count", 0)
    total_sz = stats.get("total_size_human", "0 Go")

    # 1. Stats
    li1 = xbmcgui.ListItem(label=f"📈 Médiathèque : {m_count} Films | {s_count} Séries ({ep_count} Ép.) — {total_sz}")
    li1.setInfo("video", {"plot": f"Statistiques complètes :\n- Films : {m_count}\n- Séries : {s_count}\n- Épisodes : {ep_count}\n- Espace total occupé : {total_sz}"})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{PLUGIN_URL}?action=dashboard_popup", listitem=li1, isFolder=False)

    # 2. Services
    svc_desc = "\n".join([f"{'🟢' if s.get('status') == 'online' else '🔴'} {s.get('name', s.get('type'))} : {s.get('status').upper()} ({s.get('url')})" for s in services])
    li2 = xbmcgui.ListItem(label=f"🖥️ Santé des Services : {online_svc}/{total_svc} Opérationnels")
    li2.setInfo("video", {"plot": f"État des services connectés à ArrMada :\n\n{svc_desc}"})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{PLUGIN_URL}?action=dashboard_popup", listitem=li2, isFolder=False)

    # 3. Disks
    for d in disks:
        path = d.get("path", "")
        free = d.get("free_human", "")
        total = d.get("total_human", "")
        pct = d.get("usage_percent", 0)
        li_d = xbmcgui.ListItem(label=f"💾 Stockage {path} : {free} libres / {total} ({pct}% utilisé)")
        li_d.setInfo("video", {"plot": f"Dossier / Point de montage : {path}\nEspace libre : {free}\nEspace total : {total}\nUtilisation : {pct}%"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{PLUGIN_URL}?action=dashboard_popup", listitem=li_d, isFolder=False)

    # 4. Downloads
    li4 = xbmcgui.ListItem(label=f"📥 Téléchargements actifs : {len(downloads)} en cours")
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{PLUGIN_URL}?action=downloads", listitem=li4, isFolder=False)

    # 5. Recent Activity
    for a in activities[:10]:
        t = a.get("time", "")
        title = a.get("title", "")
        det = a.get("detail", "")
        cat = a.get("category", "").upper()
        li_a = xbmcgui.ListItem(label=f"📜 [{t}] [{cat}] {title}")
        li_a.setInfo("video", {"plot": f"Heure : {t}\nCatégorie : {cat}\nTitre : {title}\nDétail : {det}"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{PLUGIN_URL}?action=dashboard_popup", listitem=li_a, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def main():
    """Router."""
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        raw_query = sys.argv[2].lstrip("?")
        params = dict(urllib.parse.parse_qsl(raw_query))

    action = params.get("action")

    if not action:
        show_root_menu()
    elif action == "search_input":
        query = xbmcgui.Dialog().input("🏴‍☠️ ArrMada : Rechercher un film ou une série")
        if query:
            xbmc.executebuiltin(f"ActivateWindow(videos,{PLUGIN_URL}?action=search_results&q={urllib.parse.quote(query)},return)")
    elif action == "search_results":
        handle_search_results(params.get("q", ""))
    elif action == "trending_movies":
        show_trending_movies()
    elif action == "trending_series":
        show_trending_series()
    elif action == "recommendations":
        show_recommendations()
    elif action == "dashboard":
        show_dashboard_directory()
    elif action == "dashboard_popup":
        show_dashboard_dialog()
    elif action == "media_details":
        show_media_details_dialog(params)
    elif action == "downloads":
        show_downloads_dialog()
    elif action == "sync":
        show_notification("ArrMada", "Scan de la médiathèque demandé...", time_ms=2500)
        ArrMadaAPI.trigger_sync()
        show_notification("ArrMada", "Scan démarré !", is_error=False)
    elif action == "clean":
        show_notification("ArrMada", "Nettoyage demandé...", time_ms=2500)
        ArrMadaAPI.trigger_clean()
        show_notification("ArrMada", "Nettoyage démarré !", is_error=False)
    elif action == "settings":
        ADDON.openSettings()




if __name__ == "__main__":
    main()
